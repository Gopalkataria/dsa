#ifndef HELPER_H
#define HELPER_H

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <string.h>

#include <stdbool.h>

#define MAX_STR_LEN 100

char *initializeString(char *strn);

void printhelp() ; 
void inpUserAndCaption() ; 
#endif